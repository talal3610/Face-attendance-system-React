import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AdminLogin from "./components/Adminlogin";
import AdminDashboard from "./components/AdminDashboard"; // Admin Dashboard
import Dashboard from "./components/dashboard";
import UserLogin from "./components/UserLogin";
import UserDashboard from "./components/UserDashboard";
import RegisterPage from "./components/RegisterPage";
import ViewAttendance from "./components/ViewAttendance";
import MarkAttendace from "./components/MarkAttendance";
import DeleteUser from "./components/DeleteUser";
import ViewAllUsers from "./components/ViewAllUsers";
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/admin" element={<AdminLogin />} />
        <Route path="/user" element={<UserLogin />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/user-dashboard" element={<UserDashboard />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/view-attendance" element={<ViewAttendance/>} />
        <Route path="/markattendance" element={<MarkAttendace/>}/>
        <Route path="/deleteuser" element={<DeleteUser/>}/>
        <Route path="/viewallusers" element={<ViewAllUsers/>}/>
      </Routes>
    </Router>
  );
}

export default App;
