import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
function MarkAttendance(){
    return(
        <h1>Mark Attendance</h1>
    )
}
export default MarkAttendance;