import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
function DeleteUser(){
    return(
        <h1>Delete User</h1>
    )
}
export default DeleteUser;