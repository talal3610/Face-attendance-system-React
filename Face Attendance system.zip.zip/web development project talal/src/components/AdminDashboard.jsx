import React from "react";
import { Link } from "react-router-dom"; // Import Link for routing
import "./AdminDashboard.css"; // Import your custom CSS
import Navbar from"./Navbar";
function AdminDashboard() {
  return (
    <div className="admin-dashboard-container">
      <h1 className="admin-dashboard-title">Admin Dashboard</h1>
      <div className="admin-dashboard-button-container">
        <Link to="/register" className="admin-dashboard-button">
          Register User
        </Link>
        <Link to="/markattendance" className="admin-dashboard-button">
          Mark Attendance
        </Link>
        <Link to="/deleteuser" className="admin-dashboard-button">
          Delete User
        </Link>
        <Link to="/viewallusers" className="admin-dashboard-button">
          View All Users
        </Link>
      </div>
    </div>
  );
}

export default AdminDashboard;
