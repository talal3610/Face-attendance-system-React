import React from "react";
import { Link } from "react-router-dom"; // Import Link for routing
import "./UserDashboard.css"; // Import your custom CSS file

function UserDashboard() {
  return (
    <div className="user-dashboard-container">
      <h1 className="user-dashboard-title">User Dashboard</h1>
      <div className="user-dashboard-button-container">
        {/* Link to the attendance page (if needed) */}
        <Link to="/view-attendance" className="user-dashboard-button">
          View Attendance
        </Link>
      </div>
    </div>
  );
}

export default UserDashboard;
