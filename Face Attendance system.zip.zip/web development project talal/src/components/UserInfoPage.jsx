import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { getDatabase, ref, set } from "firebase/database";
import "./UserInfoPage.css";

function UserInfoPage() {
  const location = useLocation();
  const navigate = useNavigate();

  // Retrieve the data passed from RegisterPage
  const { faceEncoding, capturedImage } = location.state || {};

  // Debugging: log the received state
  useEffect(() => {
    console.log("Received from RegisterPage:", location.state);
  }, [location.state]);

  const [username, setUsername] = useState("");
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleRegister = () => {
    if (!username || !userId || !password) {
      setError("All fields are required.");
      return;
    }

    // Save data to Firebase
    const db = getDatabase();
    const userIdRef = ref(db, 'users/' + userId);

    set(userIdRef, {
      username,
      userId,
      password,
      faceEncoding, // Save the face encoding (make sure it is serializable)
      capturedImage // Save the captured image
    })
    .then(() => {
      navigate("/success"); // Navigate to success page or dashboard
    })
    .catch((err) => {
      setError("Error registering user: " + err.message);
    });
  };

  return (
    <div className="user-info-container">
      {/* Display error message if any */}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* Conditionally display the captured image */}
      {capturedImage && (
        <div className="image-preview">
          <img src={capturedImage} alt="Captured Face" />
        </div>
      )}

      {/* Form to enter username, user ID, and password */}
      <div className="user-info-form">
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="text"
          placeholder="User ID"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleRegister}>Register</button>
      </div>
    </div>
  );
}

export default UserInfoPage;
