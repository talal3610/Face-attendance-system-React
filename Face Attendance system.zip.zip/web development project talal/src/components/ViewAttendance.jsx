import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
function ViewAttendance(){
    return(
        <h1>View Attendance</h1>
    )
}
export default ViewAttendance;