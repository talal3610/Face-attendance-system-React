import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
function ViewAllUsers(){
    return(
        <h1>View All users</h1>
    )
}
export default ViewAllUsers;