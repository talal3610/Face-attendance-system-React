import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as FaceDetection from "@mediapipe/face_detection";
import { Camera } from "@mediapipe/camera_utils";
import "./RegisterPage.css";

function RegisterPage() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [error, setError] = useState(null);
  const [faceEncoding, setFaceEncoding] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);
  const [isFaceDetected, setIsFaceDetected] = useState(false);
  const streamRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const startWebcam = async () => {
      try {
        // Get all available video devices
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = devices.filter((device) => device.kind === "videoinput");

        // Log available devices for debugging
        console.log("Available video devices:", videoDevices);

        // Select the Iriun webcam or default device if not found
        const selectedDevice = videoDevices.find((device) =>
          device.label.toLowerCase().includes("iriun") || device.deviceId.includes("iriun")
        ) || videoDevices[0]; // Fallback to the first device if Iriun is not found

        if (!selectedDevice) {
          throw new Error("No video devices found. Please connect a camera.");
        }

        // If stream is already active, stop the previous tracks
        if (streamRef.current) {
          const tracks = streamRef.current.getTracks();
          tracks.forEach((track) => track.stop());
        }

        // Use the deviceId to start the stream
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { deviceId: selectedDevice.deviceId },
        });

        streamRef.current = stream;

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          startFaceDetection(videoRef.current); // Start face detection after stream is active
        }
      } catch (error) {
        console.error("Error accessing webcam:", error);
        setError("Unable to access the webcam. Please ensure permissions are granted.");
      }
    };

    const startFaceDetection = (videoElement) => {
      const faceDetection = new FaceDetection.FaceDetection({
        locateFile: (file) =>
          `https://cdn.jsdelivr.net/npm/@mediapipe/face_detection/${file}`,
      });

      faceDetection.setOptions({
        model: "short",
        minDetectionConfidence: 0.7,
      });

      faceDetection.onResults((results) => {
        handleFaceDetectionResults(results);
      });

      const camera = new Camera(videoElement, {
        onFrame: async () => {
          await faceDetection.send({ image: videoElement });
        },
        width: 1280,
        height: 720,
      });

      camera.start();
    };

    const handleFaceDetectionResults = (results) => {
      drawFaceBoundingBox(results);

      if (results.detections && results.detections.length > 0) {
        setIsFaceDetected(true);
        const encoding = results.detections[0]; // Store face encoding here
        setFaceEncoding(encoding);
        captureImage(); // Capture image if face is detected
      } else {
        setIsFaceDetected(false);
      }
    };

    const captureImage = () => {
      const canvas = document.createElement("canvas");
      const context = canvas.getContext("2d");
      const video = videoRef.current;

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      const image = canvas.toDataURL("image/png");
      setCapturedImage(image);
    };

    const drawFaceBoundingBox = (results) => {
      if (!canvasRef.current || !videoRef.current) return;

      const canvasCtx = canvasRef.current.getContext("2d");
      const videoWidth = videoRef.current.videoWidth;
      const videoHeight = videoRef.current.videoHeight;

      canvasRef.current.width = videoWidth;
      canvasRef.current.height = videoHeight;

      canvasCtx.clearRect(0, 0, videoWidth, videoHeight);

      if (results.detections) {
        results.detections.forEach((detection) => {
          const boundingBox = detection.boundingBox;
          const startX = boundingBox.x * videoWidth;
          const startY = boundingBox.y * videoHeight;
          const boxWidth = boundingBox.width * videoWidth;
          const boxHeight = boundingBox.height * videoHeight;

          canvasCtx.beginPath();
          canvasCtx.rect(startX, startY, boxWidth, boxHeight);
          canvasCtx.lineWidth = 4;
          canvasCtx.strokeStyle = "red";
          canvasCtx.stroke();
          canvasCtx.closePath();
        });
      }
    };

    startWebcam();

    return () => {
      if (streamRef.current) {
        const tracks = streamRef.current.getTracks();
        tracks.forEach((track) => track.stop());
      }
    };
  }, []); // Run only once on component mount

  const handleRegister = () => {
    if (faceEncoding && capturedImage) {
      navigate("/user-info", {
        state: {
          faceEncoding,
          capturedImage,
        },
      });
    } else {
      setError("Please ensure a face is detected before registering.");
    }
  };

  return (
    <div className="register-container">
      {error && <p style={{ color: "red" }}>{error}</p>}
      <div className="video-container">
        <video ref={videoRef} autoPlay playsInline className="video-feed" />
        <canvas ref={canvasRef} className="canvas-overlay" />
      </div>
      <div className="register-button-container">
        <button onClick={handleRegister} disabled={!isFaceDetected}>
          Register
        </button>
      </div>
    </div>
  );
}

export default RegisterPage;
